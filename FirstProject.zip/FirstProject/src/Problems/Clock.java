package Problems;

public class Clock {
	
	public static void main(String [] args) {
		MyClock clock = new MyClock(10,52,5);
		MyClock clock1 = new MyClock(10,52,5);
		
		System.out.println(clock1);
	}
	
}
