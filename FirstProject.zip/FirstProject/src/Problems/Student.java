package Problems;

public class Student {
	
	private String name;

	@Override
	public String toString() {
		return "Student [name=" + name + "]";
	}

	public Student(String name) {
		this.name = name;
		
	}
	
	public Student() {
		this.name = name;
	}



}
