package Problems;

public class CallStudentName {
	
	public static void main(String[] args) {
		Student st = new Student("Umang");
		System.out.println(st);
	}

}

//   http:///www.beginwithjava.com/java/classes-ii/questions.html