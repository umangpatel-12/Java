package Student;

public class CallEmployee {

	public static void main(String[] args) {
        Employee emp = new Employee();
        emp.setName("Dhruv");
        emp.setAddres("Ahmedabad");
        emp.setEmial("dap@gmail.com");
        emp.setSalary(12000000);
        emp.setDesig("Software Testing");

        System.out.println(emp);

    }
	
}
