package Student;

import java.util.*;

public class student {

	public static void main(String[] args) {
		int n1,n2;
		int i;
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Numbers : ");
		n1 = sc.nextInt();
		sc.close();
//		n2 = sc.nextInt();
//		System.out.println(n1+n2);
//		System.out.println(n1-n2);
//		System.out.println(n1*n2);
//		System.out.println((float)n1/n2);
		
//		if(n1>90) {
//			System.out.println("Grade A");
//		}
//		else if(n1>=80 && n1<=90) {
//			System.out.println("Grade B");
//		}
//		else {
//			System.out.println("Grade C");
//		}
//		
//		do{
//			
//			System.out.println(n1);
//			n1++;
//			i++;
//			5
//		}while(i<=10);
		
		for(int j=10;j>0;j--) {
			System.out.println(j);
		}
		
	}

}
