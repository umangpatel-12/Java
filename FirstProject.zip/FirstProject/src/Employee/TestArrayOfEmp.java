package Employee;

public class TestArrayOfEmp {
	public static void main(String[] args) {
		ArryofEmployee emp = new ArryofEmployee();
		System.out.println();
	}
}
